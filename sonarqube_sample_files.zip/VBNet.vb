Module HelloWorld
 Sub Main()
 Console.WriteLine("Hello, World!")
 End Sub
End Module